import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";


const firebaseConfig = {
    apiKey: "AIzaSyDxm7mjybZJZ4fnX2FhIDJ2OGc8Bzzo_fE",
    authDomain: "furnitureshop-38198.firebaseapp.com",
    projectId: "furnitureshop-38198",
    storageBucket: "furnitureshop-38198.appspot.com",
    messagingSenderId: "106639656314",
    appId: "1:106639656314:web:1021a41dfd732e01f682c3",
    measurementId: "G-LKXKZR0BCD"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);