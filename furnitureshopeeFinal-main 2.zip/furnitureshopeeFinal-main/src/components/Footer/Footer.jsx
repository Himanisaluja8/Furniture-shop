import React from 'react';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="about-us">
          <h4>ABOUT US</h4>
          <p>
            Your life, in your style, at the right price, 
            that’s Lifestyle Furniture! Whether it's your 
            first home to entertain in, a family home to grow in,
             or just a place to relax in... Lifestyle Furniture's range 
             suits all lives and all styles, at the right price.
          </p>
        </div>

        <div className="connect-with-us">
          <h4>CONNECT WITH US</h4>
          <ul>
            <li>ABOUT US</li>
            <li>STORE LOCATIONS</li>
            <li>PAYMENT OPTIONS</li>
            <li>SERVICE REQUEST</li>
            </ul>
            </div>
            <div>
            <ul>
            <li>POLICIES</li>
            <li>TERMS & CONDITIONS</li>
            <li>DELIVERY & PICKUPS</li>
            <li>TERMS OF SERVICE</li>
            <li>REFUND & EXCHANGE</li>
          </ul>
          
        </div>
      </div>
    </footer>
  );
}

export default Footer;
