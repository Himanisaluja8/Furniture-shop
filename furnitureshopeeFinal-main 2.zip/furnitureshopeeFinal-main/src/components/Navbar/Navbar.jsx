import React from 'react';
import { NavLink } from "react-router-dom";

function NavBar() {

    const nav___links = [
        {
            path: 'bedndmat',
            display: 'BEDS AND MATTRESSES'
        },
        {
            path: 'sofa',
            display: 'SOFAS AND RECLINERS'
        },
        {
            path: 'living',
            display: 'LIVING'
        },
        {
            path: 'dining',
            display: 'DINING'
        },

        {
            path: 'homeware',
            display: 'HOMEWARES'
        },
    ]

  return (
 
    <div className="navigation">             
                <ul className="menu">

                   {
                    nav___links.map((item, index) =>(
                        <li className="nav_item" key={index}>
                        <NavLink 
                        to={item.path} 
                        className={(navClass)=>
                        navClass.isActive ? 'nav__active': ""
                        }
                        >
                        {item.display}
                        </NavLink>
                    </li>
                    ))}
            
                    </ul> 
                </div> 
  );
}

export default NavBar;