import "./App.css";

import Layout from "./components/Layout/Layout";


import  {UserAuthContextProvider} from "./Context/UserAuthContext";

function App() {
  return <Layout />
}

export default App;
