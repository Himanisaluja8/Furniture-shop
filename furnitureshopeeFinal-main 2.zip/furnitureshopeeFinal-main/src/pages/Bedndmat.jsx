import React from 'react';
import "./Bedndmat.css";

function Bedndmat() {
  const products = [
    {
      name: "Cozy Dream Sleep Bed - LIFESTYLE FURNITURE",
      price: "$658",
      description: "Cozy Dream Sleep Bed",
    },
    {
      name: "Sky Dream Sleep Bed - LIFESTYLE FURNITURE",
      price: "$578",
      description: "Sky Dream Sleep Bed",
    },
    {
      name: "Sleepmax Pillowtop Bed - LIFESTYLE FURNITURE",
      price: "$628",
      description: "Sleepmax Pillowtop Bed",
    },
    {
      name: "Loft Dream Sleep Bed - LIFESTYLE FURNITURE",
      price: "$798",
      description: "Loft Dream Sleep Bed",
    },
  ];

  return (
    <div className="product-list">
      <h2>BED BASE WITH MATTRESS</h2>
      <p>Showing {products.length} products</p>
      <div className="product-options">
        <label>Display:</label>
        <select>
          <option>10 per page</option>
          <option>20 per page</option>
          <option>30 per page</option>
        </select>
        <label>Sort by:</label>
        <select>
          <option>Best selling</option>
          <option>Price: Low to High</option>
          <option>Price: High to Low</option>
        </select>
      </div>
      <div className="product-grid">
        {products.map((product, index) => (
          <div className="product-card" key={index}>
            <h3>{product.name}</h3>
            <p>From {product.price}</p>
            <p>{product.description}</p>
            
          </div>
        ))}
      </div>
    </div>
  );
}

export default Bedndmat;
