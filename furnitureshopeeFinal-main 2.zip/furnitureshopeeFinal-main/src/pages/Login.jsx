import {useState }from 'react';
import { Link } from "react-router-dom";
import { auth } from "../Context/fb-config";
import { signInWithEmailAndPassword } from "firebase/auth"; 
import "./Login.css";

  const Login = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState(null);
  
    const handleLogin = async (e) => {
      e.preventDefault();
  
      try {
        await signInWithEmailAndPassword(auth, email, password);
        // Handle successful login (e.g., navigate to a different page)
      } catch (error) {
        setError(error.message);
      }
    };
  
    return (
      <div>
        <h2>Login</h2>
        {error && <p>{error}</p>}
        <form onSubmit={handleLogin}>
          <label>
            Email:
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </label>
          <label>
            Password:
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </label>
          <button type="submit">Log in</button>
        </form>
        <p>
          Don't have an account? <Link to="/signup">Sign up</Link>
        </p>
      </div>
    );
};

export default Login;
