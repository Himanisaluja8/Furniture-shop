import react from 'react';

const Checkout = () => {
    return (
        <div>
           Checkout
        </div>
    );
}

export default Checkout;
